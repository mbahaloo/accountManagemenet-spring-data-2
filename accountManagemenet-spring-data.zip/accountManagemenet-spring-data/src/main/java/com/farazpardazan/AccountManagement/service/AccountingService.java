package com.farazpardazan.AccountManagement.service;

import com.farazpardazan.AccountManagement.beans.Account;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Component;

import java.util.List;
@EnableAutoConfiguration
@Component
public interface AccountingService{
    public Account findAccountById(Long id);
    public Account findAccountByAccountNO(String accountNO);
    public Account createAccount(Account account);
    public Account updateAccount(Account account);
    public void deleteAccount(String accountNO);
    public void deleteAccount(Long id);
    public List<Account> getAllAccounts();
}
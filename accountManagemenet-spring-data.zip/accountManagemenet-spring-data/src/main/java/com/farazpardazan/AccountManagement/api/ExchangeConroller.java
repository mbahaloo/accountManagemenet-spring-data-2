package com.farazpardazan.AccountManagement.api;

import com.farazpardazan.AccountManagement.enums.CCY;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

@RestController
@RequestMapping(value = "/api")
public class ExchangeConroller {
    @RequestMapping(method = RequestMethod.GET, value = "/exchange/{srcCCY}/{desCCY}/{amount}")
    public Integer exchange(@PathVariable("srcCCY") CCY srcCCY,
                            @PathVariable("desCCY") CCY desCCY,
                            @PathVariable("amount") Integer amount) {
        Random rand = new Random();

        if (srcCCY == CCY.dollar && desCCY == CCY.rial) {
            float randValue = rand.nextInt(50);
            return Math.round(110000 * amount + randValue);

        } else {
            return amount;
        }
    }
}
